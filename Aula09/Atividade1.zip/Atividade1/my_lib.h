void calculoVantagens(float *salarioBruto, float *salarioFamilia, float *vantagens, float *numeroHoras, float *salarioHora, int *numeroFilhos, float *valorPorFilho);
void calculoDeducoes(float *salarioBruto, float *inss, float *irpf, float *deducoes, float *taxaIR);
